# x86-x64 插件和内核版本。
## 👉使用本固件前，请严格遵守国家互联网使用相关法律规定,不要违反国家法律规定！👈
### 默认编译  
- 用户名：root 密码：password  管理IP：192.168.2.1

- 固件格式 openwrt-x86-64-generic-squashfs-combined-efi.img.gz  
特别感谢以下项目：

Openwrt 官方项目：

<https://github.com/openwrt/openwrt>

Lean 大的 Openwrt 项目：

<https://github.com/coolsnowwolf/lede>

immortalwrt 的 OpenWrt 项目：

<https://github.com/immortalwrt/immortalwrt>

P3TERX 大佬的 Actions-OpenWrt 项目：

<https://github.com/P3TERX/Actions-OpenWrt>

DHDAXCW 大佬的 Actions-OpenWrt 项目：

https://github.com/DHDAXCW/FusionWRT_x86_x64
